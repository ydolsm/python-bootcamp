numbers = [1, 2, 3, 4, 5]
numbers_squared = map(lambda x: x**2, numbers)
print(list(numbers_squared))
