count = 0
count_complete = False

# Based on the command, add by one, subtract by one, or end
while not count_complete:
    command = input("Command (+, -, up, down, add, sub): ")
    # Add code here

print("Final count:", count)
