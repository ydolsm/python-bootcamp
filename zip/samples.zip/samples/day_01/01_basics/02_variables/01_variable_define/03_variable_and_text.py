# Variable Printing
message = "Test Message"
print(message)

# Literal Printing
print("message")