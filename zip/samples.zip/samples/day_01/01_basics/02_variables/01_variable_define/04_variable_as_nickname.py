name = "José Protacio Rizal Mercado y Alonso Realonda"
print(name)