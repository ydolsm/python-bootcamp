message = "Hello! My name is Jeff"
extra_message = "I am learning Python!"

print(message)
print(extra_message)