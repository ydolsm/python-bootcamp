result = 9999
print(result)

result = 1
print(result)