result = 9999

# Change to result + 1 then print

# Change to result * 3 then print