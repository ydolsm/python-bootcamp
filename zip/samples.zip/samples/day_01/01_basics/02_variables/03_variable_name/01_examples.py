"""
Variable Naming
 - Variable names are case-sensitive and can use all letters of most alphabets
 - Variable names can use numbers (0-9) but it can’t be at the start of the name
 - Variable names cannot use special characters except underscores (_)

Invalid Examples:
3example = 123
variable spaced = “Siomai Sioman Shupao”
alert! = “This is important!”
"""