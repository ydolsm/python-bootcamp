# Uncomment the variables and check if they are valid

# correct = "True"
# years taken beforehand = 12
# _hidden = "Please keep this a secret"
# $var = 123
# million_dollars = 1000000.00
# 何でもない = ""