empty_string_a = ''
empty_string_b = ""
quote = "I am a little teapot, short and spout."