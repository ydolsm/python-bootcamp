zero = 0
negative_number = -1
large_number = 111_222_333