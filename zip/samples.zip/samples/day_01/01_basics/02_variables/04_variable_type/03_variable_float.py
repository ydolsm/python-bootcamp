zero_float = 0.0
negative_float = -1.2
long_float = 111_222.333_444