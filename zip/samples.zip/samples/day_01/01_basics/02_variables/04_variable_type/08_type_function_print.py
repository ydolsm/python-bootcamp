data_type = type("Hello World")
print(data_type)