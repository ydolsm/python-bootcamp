first = "First Message"
second = "Second Message"
message = "Third Message"

print(first, second, message)