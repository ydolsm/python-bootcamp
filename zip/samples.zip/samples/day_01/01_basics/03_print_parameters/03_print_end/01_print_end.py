print("First", end="! ")
print("Second", end="! ")