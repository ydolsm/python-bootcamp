# Single quote
print('Single Quote:', '\'')

# Double quote
print('Double Quote:','\"')

# Backslash
print('Backslash:', '\"')

# Tab
print('Tab:','\t', 'text')

# Newline
print('Newline:', '\n', 'text')