first = "First Message"
second = "Second Message"

# Create the following outputs (without editing the variables)
# First Message!!!
# Second Message...