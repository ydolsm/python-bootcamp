user_input = input()
print(user_input)