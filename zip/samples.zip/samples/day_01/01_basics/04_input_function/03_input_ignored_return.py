input("Type anything in the console")

# How do we print the input
print()