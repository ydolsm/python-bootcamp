user_input = input("Type anything in the console")
print(user_input)