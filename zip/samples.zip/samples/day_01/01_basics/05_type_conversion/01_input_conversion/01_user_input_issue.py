number_input = input("Type any number in the console: ")
print(number_input + 1)