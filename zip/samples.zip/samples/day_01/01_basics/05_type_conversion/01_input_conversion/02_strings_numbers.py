# Valid Operation
number = 123
number = number + 1
print(number)

# Invalid operation
# number = "123"
# number = number + 1
# print(number)