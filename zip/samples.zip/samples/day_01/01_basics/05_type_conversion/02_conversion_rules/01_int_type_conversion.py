# Float to Integer Conversion
float_example1 = 1.1
float_example2 = 1.9

print(int(float_example1), int(float_example2))

# Boolean to Integer Conversion
bool_true = True
bool_false = False

print(int(bool_true), int(bool_false))

# String to Integer Conversion
string_example = "12345"
print(int(string_example))