# Integer to Float Conversion
int_example = 3
print(float(int_example))

# Boolean to Float Conversion
bool_true = True
bool_false = False

print(float(bool_true), float(bool_false))

# String to Float Conversion
string_example = "12345.12"
print(float(string_example))