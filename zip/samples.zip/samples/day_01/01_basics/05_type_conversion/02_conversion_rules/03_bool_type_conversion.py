# False Conversions
false_int = 0
false_float = 0.0
false_string = ""
false_none = None

print(bool(false_int))
print(bool(false_float))
print(bool(false_string))
print(bool(false_none))