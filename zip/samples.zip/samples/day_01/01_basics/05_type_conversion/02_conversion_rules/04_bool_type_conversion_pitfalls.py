space_string = " "
false_string = "False"
none_string = "None"

print(bool(space_string))
print(bool(false_string))
print(bool(none_string))