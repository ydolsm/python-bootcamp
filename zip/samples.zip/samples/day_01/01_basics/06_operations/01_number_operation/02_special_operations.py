# Floor Division
division_result = 11 / 2
floor_division_result = 11 // 2

print(division_result, floor_division_result)

# Exponent / Power
result = 11 / 2
print(result)

# Modulo / Remainder
result = 11 % 2
print(result)