# Initial Value
result = "ice "
print(result)

# Equivalent to:
# result = result * 3
result *= 3
print(result)

# Equivalent to:
# result = result + "baby"
result += "baby"
print(result)