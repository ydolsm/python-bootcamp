# Python follows the PEMDAS order of operations
result = 3 + (5 * 2) - (8 / 4)
print(result)