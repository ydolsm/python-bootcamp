# Placeholder messages
name_message = "Your name is {}."
number_message = "Your favorite number is {}."
color_message = "Your favorite color is {}."

# Ask the user for their inputs
user_name = None
favorite_number = None
favorite_color = None

# Print the template with the placeholders replaced


