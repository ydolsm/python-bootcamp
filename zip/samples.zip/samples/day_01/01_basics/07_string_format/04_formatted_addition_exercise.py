# Given the following inputs
number1 = int(input("First number: "))
number2 = int(input("Second number: "))

# Print the following result
# Addition: number1 + number2 = number1 + number2 sum