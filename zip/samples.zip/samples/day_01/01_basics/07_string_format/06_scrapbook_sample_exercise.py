# Ask the user for their inputs
user_name = None
favorite_number = None
favorite_color = None

# Print the following messages:
# Hello, my name is: user_name. That’s a nice name!
# My favorite number is: favorite_number. Nice choice.
# My favorite color is: favorite_color. Hopefully we see it today.