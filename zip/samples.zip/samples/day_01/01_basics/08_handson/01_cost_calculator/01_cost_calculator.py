# Ask the user for the information of three items
item_1_price = None
item_2_price = None
item_3_price = None

# Calculate the total cost
total_cost = None

# Print total cost
