# Ask the user for a message
message = None

# Ask the user for a number
message_count = None

# Ask the user for a number
line_count = None

# Depending on the number of message_count, repeat message that many times
# Example: message = "Paulit-ulit na lang.", message_count = 3
# Output:
# Paulit-ulit na lang. Paulit-ulit na lang. Paulit-ulit na lang

# Additionally, depending on the number of line_count, repeat the line that many times
# Example: message = "Paulit-ulit na lang", message_count = 3, line_count = 5
# Output:
# Paulit-ulit na lang. Paulit-ulit na lang. Paulit-ulit na lang
# Paulit-ulit na lang. Paulit-ulit na lang. Paulit-ulit na lang
# Paulit-ulit na lang. Paulit-ulit na lang. Paulit-ulit na lang
# Paulit-ulit na lang. Paulit-ulit na lang. Paulit-ulit na lang
# Paulit-ulit na lang. Paulit-ulit na lang. Paulit-ulit na lang