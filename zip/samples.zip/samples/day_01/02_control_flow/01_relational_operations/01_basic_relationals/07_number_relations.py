# Replace each None with an integer input
first_number = None
second_number = None

# Print the result of the >, <, ==, and != operations on both