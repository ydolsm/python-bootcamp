number_1 = 10
number_2 = int(input("Enter a number: "))
number_3 = 30

print(number_1 <= number_2 <= number_3)