# Replace each None with an integer input
min_number = None
max_number = None
number = None

# Print True or False depending on if number is in between the two numbers (inclusive)
