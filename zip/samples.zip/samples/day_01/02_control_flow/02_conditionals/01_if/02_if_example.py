number = int(input("Enter number: "))

if number > 0:
    print("Number greater than zero!")
