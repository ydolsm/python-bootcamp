correct_password = "pass"
password_input = input("Please provide a password: ")

# Print "Access Granted!" if password is correct

