you_said = input("You said: ")

if you_said == "Wish":
	print("107.5")
elif you_said == "Hello":
	print("...it's. me")
elif you_said == "Jopay":
	print("...kamusta ka na")
elif you_said == "Black Pink":
	print("...in your area")

