# Ask the user input for a color
color_input = input("Please enter a color: ")

# Then print the following depending on the color input:
# 	green -> Go!
# 	yellow -> Wait...
# 	red -> Stop!
#   anything else -> "Malfunction"