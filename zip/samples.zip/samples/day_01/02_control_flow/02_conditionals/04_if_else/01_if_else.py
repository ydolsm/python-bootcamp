number = int(input("Enter a number: "))
if number % 2 == 0:
	print(f"Number {number} is even")
else:
	print(f"Number {number} is odd")