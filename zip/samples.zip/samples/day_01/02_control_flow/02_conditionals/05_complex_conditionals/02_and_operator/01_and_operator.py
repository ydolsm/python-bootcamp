number = int(input("Provide a number: "))
if number > 0 and number % 2 == 1:
	print("You gave a positive AND odd number")
