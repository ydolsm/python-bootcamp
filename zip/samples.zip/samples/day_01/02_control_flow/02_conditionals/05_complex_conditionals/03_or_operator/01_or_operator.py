response = input("Continue? ")
if response == "yes" or response == "YES":
	print("We will continue!")
