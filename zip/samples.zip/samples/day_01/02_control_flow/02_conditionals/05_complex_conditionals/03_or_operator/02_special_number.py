# Ask the user for a number
number = int(input("Provide a number: "))

# Check if the number is special (equal to zero, one, or ten).
# Then print the appropriate result:
# 	True -> "Special Number Detected!"
# 	False -> "Not a Special Number!"