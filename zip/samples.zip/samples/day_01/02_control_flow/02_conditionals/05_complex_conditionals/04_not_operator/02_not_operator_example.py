number = int(input("Number: "))

divisible_by_three = number % 3 == 0

print(not divisible_by_three)
print(not number % 3 == 0)
