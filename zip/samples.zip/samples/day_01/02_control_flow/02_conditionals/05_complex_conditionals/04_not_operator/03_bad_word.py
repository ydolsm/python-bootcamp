# Create a variable with the word the user shouldn’t give
bad_word = "ice cream"

# Then ask the user for an input
user_input = input("Please provide any input: ")

# Print the following response based on the input
#   not bad word -> "That's a good word!"
#   bad word -> "That's a bad word!"