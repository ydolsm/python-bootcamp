for item in range(3):
	print("This will be repeated")

