# Print the line eleven times:
# 	"This is a very long line that can take some time for you to type."