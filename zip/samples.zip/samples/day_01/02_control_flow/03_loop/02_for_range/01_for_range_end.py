for item in range(3):
    print(item)