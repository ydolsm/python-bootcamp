# Print the following numbers per line
#   0, 1, 2, 3, ..., 100