# Print the following numbers per line
#   0, 2, 4, 6, ..., 100