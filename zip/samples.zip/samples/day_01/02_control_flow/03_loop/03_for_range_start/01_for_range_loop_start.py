for item in range(1, 3):
    print(item)