# Print the following numbers per line
#   95, 96, 97, 98, 99, 100