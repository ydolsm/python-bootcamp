# Print the following numbers per line
#   5, 10, ..., 100