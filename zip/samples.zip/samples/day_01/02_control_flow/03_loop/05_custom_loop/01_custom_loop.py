items = ["First Message", "Second Message", "Third Message"]
for item in items:
	print(item)