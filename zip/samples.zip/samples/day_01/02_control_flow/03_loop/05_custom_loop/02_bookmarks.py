favorite_sites = ["facebook.com", "youtube.com"]

# Print each site in favorite_sites by line