counter = 0

while counter < 100:
    counter = counter + 1
    print(counter)