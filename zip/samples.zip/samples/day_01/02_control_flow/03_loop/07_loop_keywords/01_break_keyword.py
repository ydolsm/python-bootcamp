for item in range(100):
	print(item)
	if item == 3:
		break
