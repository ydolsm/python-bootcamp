for item in range(100):
	if item == 3:
		continue

	print(item)