# Exercise Description:
#
#   Make a program loop that keeps asking for input
#   and ends the program when they input "exit"
#
#   At the start of the program ask for a starting number
#   Next, ask for either +, -, *, or //
#   Next, ask for another number
#   Apply the operation to the first number with the given number
#   Repeat line 7 and 8 and 9 repeatedly (don't forget to print the result)