numbers = [1, 3, 5, 7, 2, 4, 6]
print(sum(numbers))

new_numbers = [9, 3, 0, 1, 2, 7]
print(sum(new_numbers))