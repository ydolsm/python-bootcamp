# Create a function named line_generator() that prints the following:
#	Line 0
#	Line 1
#	Line 2

# Then, use the function once:
# 	line_generator()
#
# Output:
# Line 0
# Line 1
# Line 2