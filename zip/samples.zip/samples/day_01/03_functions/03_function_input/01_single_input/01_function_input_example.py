def greet(username):
	print(f"Hello {username}, good day to you!")

greet("Joseph")