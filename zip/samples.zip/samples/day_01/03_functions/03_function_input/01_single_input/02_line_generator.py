# Create a function named line_generator()
# that takes an input line_count and prints that many lines
#	Line 0
#	Line 1
#	Line 2
# 	...

# Then, use the function once and give an input 4
# 	line_generator(4)
#
# Output:
# Line 0
# Line 1
# Line 2
# Line 3
