# Create a function named line_generator()
# that takes an input line_count and message
# and prints message for that many lines
#	message 0
#	message 1
#	message 2
# 	...

# Then, use the function once and give an input 4 and "Hello World"
# 	line_generator(4, “Hello World”)
#
# Output:
# Hello World 0
# Hello World 1
# Hello World 2
# Hello World 3