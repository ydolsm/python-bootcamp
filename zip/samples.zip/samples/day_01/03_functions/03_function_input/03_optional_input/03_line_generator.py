# Create a function named line_generator()
# that takes an input line_count and message
# and prints message for that many lines
# Set the default line_count to 1 and message to "Hello World"
#	message 0
#	message 1
#	message 2
# 	...

# Then, use the function once with no input
# 	line_generator()
#
# Output:
# "Hello World" 0
