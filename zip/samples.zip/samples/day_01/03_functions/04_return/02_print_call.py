def add(num1, num2):
    result = num1 + num2
    print(result)

add(1, 2)