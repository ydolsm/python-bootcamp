def add(num1, num2):
    result = num1 + num2
    return result

add(1, 2)