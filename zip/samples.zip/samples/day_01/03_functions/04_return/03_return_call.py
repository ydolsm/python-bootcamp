def add(num1, num2):
    result = num1 + num2
    return result

add_result = add(1, 2)
print(add_result)