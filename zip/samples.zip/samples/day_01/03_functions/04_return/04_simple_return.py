def distance(x, y):
    return (x**2 + y**2) ** (1/2)

first_distance = distance(3, 10)
second_distance = distance(10, 5)