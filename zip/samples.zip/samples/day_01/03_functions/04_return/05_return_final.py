def add(num1, num2):
	result = num1 + num2
	return result
	print(f"The result is: {result}")


result = add(3, 4)
print(result)