
print(5 / 0)
