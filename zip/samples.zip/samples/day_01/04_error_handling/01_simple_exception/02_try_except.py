try:
	print(5 / 0)
except:
	print("Please don’t divide by zero")