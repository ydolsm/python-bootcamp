number_input = int(input("Type any number: "))
print(number_input)
