number = input("Enter number: ")

# Print this message if an error occurs:
#   Invalid input. Please provide a valid integer
number_converted = int(number)

# Raise an error if the number is not positive
#   Invalid input. Please provide a positive integer