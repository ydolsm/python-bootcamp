def fizz_buzz() -> None:
    """
    Prints the numbers from 1 to 100. For multiples of 3, prints 'Fizz' instead of the number.
    For multiples of 5, prints 'Buzz' instead. For numbers that are multiples of both 3 and 5, prints 'FizzBuzz'.
    """

fizz_buzz()