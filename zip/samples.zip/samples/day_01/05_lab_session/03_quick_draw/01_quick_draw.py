# Ask the user for an input
user_choice = input("Pick a choice (rock/paper/scissors): ")

# Select a choice for the CPU
cpu_choice = None

# Depending on the user_choice and cpu_choice, print the appropriate result
#   User Win -> You win!
#   User Lost -> You Lost!
#   Draw -> Draw!

