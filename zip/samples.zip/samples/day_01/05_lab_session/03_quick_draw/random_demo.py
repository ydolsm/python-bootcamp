from random import choice

options = ["Option 1", "Option 2", "Option 3"]
print(choice(options))