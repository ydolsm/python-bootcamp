text = "I am an igloo"
example = {char for char in text if char != 'a'}

print(example)
