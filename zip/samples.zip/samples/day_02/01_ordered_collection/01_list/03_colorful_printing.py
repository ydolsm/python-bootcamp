# Replace None with your custom list of colors
colors = None
print(colors)

# Then, print each color one line at a time

