letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']

# Print the first, third, and fifth letter one line at a time
# 'a', 'c', 'e'