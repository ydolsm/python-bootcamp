letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']

# Change the first, third, and fifth letter to an asterisk
# 'a', 'c', 'e' -> '*', '*', '*'