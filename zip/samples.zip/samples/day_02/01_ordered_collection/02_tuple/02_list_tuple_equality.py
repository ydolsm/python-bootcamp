example_list = [1, 2, 3]
example_tuple = (1, 2, 3)

print(example_list == example_tuple)