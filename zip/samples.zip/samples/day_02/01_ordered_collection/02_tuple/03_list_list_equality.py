example_list1 = [1, 2, 3]
example_list2 = [3, 2, 1]

print(example_list1 == example_list2)