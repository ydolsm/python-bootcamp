example_tuple1 = (1, 2, 3)
example_tuple2 = (3, 2, 1)

print(example_tuple1 == example_tuple2)