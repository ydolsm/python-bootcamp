example_list = [1, 2, 3]
example_tuple = (1, 2, 3)

print(tuple(example_list) == example_tuple)
print(example_list == list(example_tuple))