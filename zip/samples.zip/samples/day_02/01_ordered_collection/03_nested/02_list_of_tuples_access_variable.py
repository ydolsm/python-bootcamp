student_data = [
    ("Maria", 98),
    ("Pedro", 30),
    ("Bax", 10)
]

first_record = student_data[0]
print(first_record)

first_record_score = first_record[1]
print(first_record_score)