student_data = [
    ("Maria", 98),
    ("Pedro", 30),
    ("Bax", 10)
]

first_record_score = student_data[0][1]
print(first_record_score)