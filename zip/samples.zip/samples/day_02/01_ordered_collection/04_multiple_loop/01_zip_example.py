items = ['a', 'b', 'c']
others = [1, 2, 3]

for item, other in zip(items, others):
    print(item, other)