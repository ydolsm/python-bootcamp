student_names = ["Juan", "Maria", "Joseph"]
student_scores = [70, 90, 81]

# Print the student scores and names in the following format:
# Student Records:
#   Record: Juan scored 70 in the exam.
#   Record: Maria scored 90 in the exam.
#   Record: Joseph scored 81 in the exam.
#
# Bonus Challenge: Print the highest scorer