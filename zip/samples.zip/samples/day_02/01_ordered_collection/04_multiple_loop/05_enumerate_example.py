items = ['a', 'b', 'c']
for index, items in enumerate(items):
	print(index, items)
