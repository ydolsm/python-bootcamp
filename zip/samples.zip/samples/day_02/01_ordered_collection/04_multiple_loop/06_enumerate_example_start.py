items = ['a', 'b', 'c']
for index, items in enumerate(items, start=1):
	print(index, items)
