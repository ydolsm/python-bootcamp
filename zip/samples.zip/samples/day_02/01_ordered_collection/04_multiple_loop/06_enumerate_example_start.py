items = ["a", "b", "c"]
for index, item in enumerate(items, start=1):
    print(index, item)
