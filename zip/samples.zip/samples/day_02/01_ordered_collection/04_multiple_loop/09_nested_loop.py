items = ['a', 'b', 'c']
others = [1, 2, 3]

for item in items:
    for other in others:
        print(item, other)