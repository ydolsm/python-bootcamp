food = ["ice cream", "burger", "fries"]
has_ice_cream = "ice cream" in food

print(has_ice_cream)