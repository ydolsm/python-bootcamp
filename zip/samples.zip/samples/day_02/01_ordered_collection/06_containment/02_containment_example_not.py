food = ["ice cream", "burger", "fries"]
no_ice_cream = "ice cream" not in food

print(no_ice_cream)