example = [1, 3, 3, 5, 4]

item_to_remove = 999

if item_to_remove in example:
    example.remove(item_to_remove)

print(example)