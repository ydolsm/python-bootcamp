# Create a list of names
names = ["Name 1", "Name 2", "Name 3"]

# Then ask the user for an input
user_name = input("Please provide your name: ")

# Then print the following depending on if the name is in names
#   user_name in names -> "Access Granted!"
#   user_name not in names -> "Access Denied!"
