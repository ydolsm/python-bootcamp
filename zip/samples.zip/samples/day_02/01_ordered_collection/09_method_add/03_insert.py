example = [1, 3, 3, 5, 4]

example.insert(0, 999)
print(example)
