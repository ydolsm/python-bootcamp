example = (1, 3, 3, 5, 4)

print(example.index(5))
