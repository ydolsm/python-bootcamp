example = [1, 3, 3, 5, 4]

example.pop(-1)
print(example)