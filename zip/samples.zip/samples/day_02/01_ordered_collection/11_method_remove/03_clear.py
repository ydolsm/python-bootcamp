example = [1, 3, 3, 5, 4]

example.clear()
print(example)