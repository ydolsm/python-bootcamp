example = [1, 3, 3, 5, 6, 7, 1, 2, 1, 1]

copy = example.copy()
print(copy)