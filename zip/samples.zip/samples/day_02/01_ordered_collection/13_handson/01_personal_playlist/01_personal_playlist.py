def add(song, playlist):
	"""Add song to playlist"""

def remove(song, playlist):
	"""Remove song from playlist"""

def play(playlist):
	"""Print the first song in the playlist (if any) and remove"""

def show_all(playlist):
	"""Print all contents in the playlist"""

def playlist_app():
	"""Ask user what command they want to do"""

playlist_app()