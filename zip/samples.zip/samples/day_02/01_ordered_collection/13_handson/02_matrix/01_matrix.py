# Complete the code to make a program that makes and displays a matrix
#
#   Enter row count: 3
#   Enter col count: 5
#
#   | 	1	 | 	2	 | 	3	 | 	4	 | 	5	 |
#   | 	2	 | 	4	 | 	6	 | 	8	 | 	10	 |
#   | 	3	 | 	6	 | 	9	 | 	12	 | 	15	 |


def make_matrix(row_count, col_count):
    return []

def display_matrix(matrix):
    pass

def main():
    row_count = None
    col_count = None

    new_matrix = make_matrix(row_count, col_count)
    display_matrix(new_matrix)

main()