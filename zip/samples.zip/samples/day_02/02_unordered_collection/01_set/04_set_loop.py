letters = {'a', 'a', 'b', 'c', 'd'}

for letter in letters:
    print(letter)