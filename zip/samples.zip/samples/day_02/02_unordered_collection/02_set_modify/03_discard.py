example = {1, 3, 5, 6}
print(example)

example.discard(5)
print(example)