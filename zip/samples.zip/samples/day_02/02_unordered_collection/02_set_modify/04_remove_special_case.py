# From the previous exercise, remove the attendee with the same name as you
# To verify that the last attendee name was removed, print attendee_names again