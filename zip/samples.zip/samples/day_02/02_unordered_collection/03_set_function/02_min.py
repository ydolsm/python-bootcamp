example = {1, 3, 5, 6}
print(min(example))