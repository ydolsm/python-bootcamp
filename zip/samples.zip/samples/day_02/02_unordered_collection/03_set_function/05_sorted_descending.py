example = {1, 3, 5, 6}
print(sorted(example, reverse=True))