set1 = {'a', 'b', 'c', 'd', 'e', 'f'}
set2 = {'d', 'e', 'f', 'g', 'h', 'i'}

print(set1.union(set2))
print(set1 | set2)