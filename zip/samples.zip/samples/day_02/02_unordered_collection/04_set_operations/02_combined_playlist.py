your_playlist = {
    "All I Want for Christmas is You",
    "Silent Night, Holy Night",
    "Star ng Pasko",
    "Pasko na Sinta Ko",
}

friend_playlist = {
    "Baby, It's Cold Outside",
    "All I Want for Christmas is You",
    "Kampana ng Simbahan",
    "Christmas Bonus",
}

# Create a new playlist that combines all the songs