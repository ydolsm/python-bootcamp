set1 = {'a', 'b', 'c', 'd', 'e', 'f'}
set2 = {'d', 'e', 'f', 'g', 'h', 'i'}

print(set2.difference(set1))
print(set2 - set1)
