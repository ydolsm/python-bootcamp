# Add more country codes and test this code
country_codes = {
	"PH": "Philippines",
	"US": "United States",
}

code = "PH"
print(f"{code} -> {country_codes["PH"]}")