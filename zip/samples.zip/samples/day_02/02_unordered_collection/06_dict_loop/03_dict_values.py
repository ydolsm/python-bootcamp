student_records = {
	"Juan": 70,
	"Maria": 98,
    "Joseph": 81,
    "Elise": 80,
}

for student_score in student_records.values():
	print(student_score)