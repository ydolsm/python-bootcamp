# Using your favorites dict earlier, print each key in this format:
# My Favorites:
# 	2
# 	black