# Using your favorites dict earlier, print each key and value in this format:
# My Favorites:
# 	number: 2
#   color: Black