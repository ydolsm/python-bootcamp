student_records = {
	"Juan": 70,
	"Maria": 98,
    "Joseph": 81,
    "Elise": 80,
}

removed_key = student_records.pop("Maria")
print(removed_key)