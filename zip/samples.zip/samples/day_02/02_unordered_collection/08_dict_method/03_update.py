student_records = {
	"Juan": 70,
	"Maria": 98,
    "Joseph": 81,
    "Elise": 80,
}

new_student_records = {
    "Bax": 22,
    "Elmo": 59,
}

student_records.update(new_student_records)
print(student_records)