product_catalog = [
    {
   	    'name': 'Smartphone',
    	'description': 'Latest model smartphone.',
        'price': 999.99,
    	'stock': 25
    },
    {
    	'name': 'Wireless Headphones',
    	'description': 'Noise-canceling wireless headphones.',
    	'price': 199.99,
    	'stock': 50
    },
]

print(product_catalog[0]['name'])