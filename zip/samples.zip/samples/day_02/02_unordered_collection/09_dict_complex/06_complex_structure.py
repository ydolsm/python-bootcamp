user_profile = {
    'name': 'Alice Smith',
    'preferences': {
        'language': ['English', 'Japanese'],
        'notifications': True,
    }
}
