movie_entry = {
	'title': 'Heneral Luna',
	'details': {
    		'release_year': 2015,
    		'genres': ['Historical', 'Drama', 'War'],
    		'ratings': 90,
	},
	'cast': {
    		'main_actors': ['John Arcilla', 'Mon Confiado'],
    		'director': ['Jerrold Tarog'],
	},
}
