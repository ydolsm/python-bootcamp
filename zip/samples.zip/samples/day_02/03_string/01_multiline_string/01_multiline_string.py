message = """
Hello World
Hello World
Hello World
"""

print(message)