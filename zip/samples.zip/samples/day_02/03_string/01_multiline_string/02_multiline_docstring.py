def helpful_function():
    """Adding a multiline string after a function definition
    creates a guide when calling the help function
    """
    return 0

help(helpful_function)