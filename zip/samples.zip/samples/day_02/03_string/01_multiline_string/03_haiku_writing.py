haiku = """
	Crisp winds brush my face
	Golden leaves dance through the air
	Whispers of cold dawn
"""
print(haiku)
