number = 123456789
print(f"{number:,}")

