# Ask the user for the information of three items

initial_balance = None
time_years = None
interest_rate = None

# Then print the following output
#     Initial Balance: PHP Initial Balance (two decimal places)
#     Time (in Years): Years (four decimal places)
#     Interest Rate: Interest Rate in Percentage (four decimal places)
#     ===================================================================
#     Simple Interest: initial_balance * (1 + interest_rate * time_years)

