items = 'abc'
for item in items:
	print(item)
