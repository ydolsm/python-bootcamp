items = 'Hello World'
print(items[:5])
