example = "Hello World"

var_example = example.lower()

print(example)
print(var_example)