example = "Hello World"

var_example = example.upper()

print(example)
print(var_example)