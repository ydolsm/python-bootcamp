example = "This is a title"

var_example = example.title()

print(example)
print(var_example)