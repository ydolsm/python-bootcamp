user_input = input("Proceed (Yes/yes/y)? ")
if user_input.lower() == "yes":
	print("Proceeding")
