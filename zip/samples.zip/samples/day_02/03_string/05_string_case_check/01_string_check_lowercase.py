example = "hello"

all_lower = example.islower()
print(example)
print(all_lower)