example = "    "

all_space = example.isupper()
print(example)
print(all_space)
