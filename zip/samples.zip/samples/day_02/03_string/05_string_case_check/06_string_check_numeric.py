example = "12345"

all_numeric = example.isnumeric()
print(example)
print(all_numeric )


