# Ask the user or an input
user_input = input("Please provide any input: ")

# Then print the following depending on if the given input is a valid number (without converting)
#   Valid Number -> "This is a valid number"
#   Invalid Number -> "This is not a valid number"