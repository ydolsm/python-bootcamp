example = "Hello World"

friendly = example.startswith("Hello")
print(example)
print(friendly)