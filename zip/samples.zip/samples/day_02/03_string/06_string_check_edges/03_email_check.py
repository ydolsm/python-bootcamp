# Ask the user for an input
email_input = input("Enter your email address: ")

# Then print the following depending on if the input is a valid gmail address.
#   Valid Gmail Address -> "This is a valid gmail."
#   Invalid Gmail Address -> "This is not a valid gmail."

