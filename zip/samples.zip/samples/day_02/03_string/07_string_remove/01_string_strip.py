example = "        Hello World                 "

clean_example = example.strip()
print(f"'{example}'")
print(f"'{clean_example}'")