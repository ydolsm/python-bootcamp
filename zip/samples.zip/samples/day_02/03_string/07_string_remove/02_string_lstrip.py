example = "        Hello World                 "

clean_example = example.lstrip()
print(f"'{example}'")
print(f"'{clean_example}'")