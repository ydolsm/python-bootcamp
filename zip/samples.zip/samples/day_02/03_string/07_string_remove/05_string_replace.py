example = "123,456,789"

alternative_example = example.replace(",", ".")
print(example)
print(alternative_example)

