example = "a, b, c, d"

alternative_example = example.replace(", ", "")
print(example)
print(alternative_example)

