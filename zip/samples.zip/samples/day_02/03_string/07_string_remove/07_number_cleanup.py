# Given a user input for a number that has unecessary spaces on the left and right, and uses commas:
#   Example: "    2,444,111   "
#
#   Convert to a valid integer in code
#   2444111