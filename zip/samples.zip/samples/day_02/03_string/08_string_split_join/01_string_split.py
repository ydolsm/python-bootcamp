example = "Hello   I    am    a   message!"

words = example.split()
print(example)
print(words)
