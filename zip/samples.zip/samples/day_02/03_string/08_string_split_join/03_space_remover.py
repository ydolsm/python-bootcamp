# Given an input with random extra spaces
# Example: "  This   is   an  excessively   spaced    sentence"
#
# Remove the extra spaces accordingly:
# Output: "This is a excessively spaced sentence"