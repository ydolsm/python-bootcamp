# Make a function that takes an input text and returns the longest word (excluding special char)

def get_longest_word(text):
	# Add decoding process
	return ""

print(get_longest_word("The quick brown fox jumps"))
print(get_longest_word("I love programming in Python!"))
print(get_longest_word(""))