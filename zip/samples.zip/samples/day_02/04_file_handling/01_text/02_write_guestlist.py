# Write the following names per line in a text file:
# 	Mia Anderson
# 	Ethan Roberts
# 	Liam Johnson
# 	Sophia Martinez
# 	Olivia Davis
# 	Noah Thompson