with open("test.txt", "a") as file:
	file.write("\nAnother Line")