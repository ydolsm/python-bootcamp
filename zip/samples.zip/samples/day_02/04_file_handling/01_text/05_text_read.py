with open("test.txt", "r") as file:
	file_contents = file.read()

print(file_contents)