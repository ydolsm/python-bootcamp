with open("test.txt", "r") as file:
	file_contents = file.read().splitlines()

print(file_contents)