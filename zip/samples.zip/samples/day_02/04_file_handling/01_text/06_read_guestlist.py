# Read the previous file and print in this format:
#
# Attendees:
# 	1.) Mia Anderson
# 	2.) Ethan Roberts
# 	3.) Liam Johnson
# 	4.) Sophia Martinez
# 	5.) Olivia Davis
# 	6.) Noah Thompson
#   7.) Alex Freze