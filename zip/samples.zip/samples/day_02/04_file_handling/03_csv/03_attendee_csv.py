"""
Create a CSV for the given data:

	Name		ID		Group
	Alice		123		A
	Bob			234		B
	Charlie		999		C
	Delta		441		D
"""