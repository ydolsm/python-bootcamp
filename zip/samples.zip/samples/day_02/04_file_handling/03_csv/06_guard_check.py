# Given a student name, ID, and Group, check if they are allowed.
# Welcome to the school, please log-in:
#   Name: user input here
#   ID: user input here
#   Group: user input here
#
# Not in database -> Print "Hey! You’re not on the list boss."
# In database -> Print "Please come in boss."