numbers = [number + 1 for number in range(11)]
print(numbers)