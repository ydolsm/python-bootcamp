numbers = []

for number in range(11):
    numbers.append(number + 1)

print(numbers)
