# Ask the user for an integer
number_count = int(input("How many to generate? "))

# Using comprehensions, make the following patterns:
#   [0, 1, 4, 9, 16, 25, 36, 49, 64, 81, 100, ...]
