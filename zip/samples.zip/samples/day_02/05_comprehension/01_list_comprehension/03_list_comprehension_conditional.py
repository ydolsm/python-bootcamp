numbers = [number for number in range(10) if number % 2 == 0]
print(numbers)
