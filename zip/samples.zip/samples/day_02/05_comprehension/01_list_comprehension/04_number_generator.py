# Ask the user for an integer
number_count = int(input("How many to generate? "))

# Using comprehensions, make the following patterns:
#   [1, 3, 5, 7, 9, 11, 13, 15, 17, 19, ...]
