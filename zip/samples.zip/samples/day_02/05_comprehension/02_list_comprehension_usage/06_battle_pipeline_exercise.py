heroes = ["Knight", "Archer", "Mage", "Cleric"]
monsters = ["Slime", "Orc", "Chocobo", "Dragon"]
pacifist = ["Cleric", "Chocobo"]

# Make a list of tuples pairing each hero with each monster
pairing = [...]

# Then, make a list of strings wherein the string with the longest length remains.
# If it’s a draw, set the value to 'Draw' instead.
# Additionally, if one of them is a pacifist, don’t include in the list.
winners = [...]

print(winners)
