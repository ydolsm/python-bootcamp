example = {
    f"Key {num}": f"Value {num}"
    for num in range(3)
}

print(example)