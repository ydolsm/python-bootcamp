class Employee:
	pass
