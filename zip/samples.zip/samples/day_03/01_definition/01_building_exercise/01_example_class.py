class Employee:
    """Class representation for employee data"""
