class Employee:
    pass

employee1 = Employee()