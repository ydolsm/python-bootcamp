class Employee:
    pass

employee1 = Employee()
employee2 = Employee()