class Employee:
    """Class representation for employee data"""


employee1 = Employee()
employee2 = Employee()
