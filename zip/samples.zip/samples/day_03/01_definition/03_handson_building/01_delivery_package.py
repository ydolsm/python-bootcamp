class DeliveryPackage:
    def __init__(self):
        """Add more attributes"""