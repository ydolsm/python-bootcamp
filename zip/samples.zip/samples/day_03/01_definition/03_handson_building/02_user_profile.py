class UserProfile:
    def __init__(self):
        """Add more attributes"""