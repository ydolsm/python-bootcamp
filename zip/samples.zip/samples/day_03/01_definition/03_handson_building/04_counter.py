class Counter:

	def __init__(self, initial_amount):
		self.count = initial_amount

	def count_clear(self):
		"""Implement this"""

	def count_up(self, amount=1):
		"""Implement this"""

	def count_down(self, amount=1):
		"""Implement this"""
