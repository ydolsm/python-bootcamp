class Number:

	def __init__(self, value):
		self.value = value

	def add(self, other):
		"""Return a new Number"""

	def minus(self, other):
		"""Return a new Number"""

	def multiply(self, other):
		"""Return a new Number"""

	def divide(self, other):
		"""Return a new Number"""
