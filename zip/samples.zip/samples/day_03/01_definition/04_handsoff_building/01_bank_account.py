class BankAccount:
    pass