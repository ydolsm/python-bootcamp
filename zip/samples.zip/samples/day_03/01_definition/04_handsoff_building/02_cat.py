class Cat:
    pass