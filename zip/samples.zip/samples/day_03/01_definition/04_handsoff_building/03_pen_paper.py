class Pen:
    pass


class Paper:
    pass