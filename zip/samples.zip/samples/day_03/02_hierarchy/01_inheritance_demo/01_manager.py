class Manager:
    def __init__(self, id):
        self.id = id

    def time_in(self):
        print('Time In')

    def time_out(self):
        print('Time Out')

    def design(self):
        print('Managing')