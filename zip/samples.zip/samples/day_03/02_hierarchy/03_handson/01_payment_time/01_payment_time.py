class Payment:
    pass


class CouponPayment(Payment):
    pass


class CardPayment(Payment):
    pass


class OnlinePayment(Payment):
    pass
