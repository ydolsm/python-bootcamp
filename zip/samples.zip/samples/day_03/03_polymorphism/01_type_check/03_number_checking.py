from numbers import Number

print(isinstance(1, Number))
print(isinstance(1.0, Number))
print(isinstance(True, Number))