def add(first, second):
	pass

"""
both int, float, or bool -> return their sum
both list, set, dict, str -> return items combined
one list, set, dict -> return collection with item added
Anything else -> raise error
"""