class Shape:
    def area(self):
        pass