"""
Define a class for a Door with the following:
    - Properties:
        - closed (bool)
    - Method
        - self.open()
        - self.close()
"""