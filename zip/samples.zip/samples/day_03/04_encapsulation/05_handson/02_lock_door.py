"""
Define a class for a Door with the following:
    - Properties:
        - closed (bool)
        - locked (bool)
    - Method
        - self.open()
        - self.close()
        - self.lock()
        - self.unlock()
"""