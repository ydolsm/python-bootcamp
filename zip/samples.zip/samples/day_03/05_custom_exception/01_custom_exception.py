class CustomError(Exception):
    pass

raise CustomError("yikes")

