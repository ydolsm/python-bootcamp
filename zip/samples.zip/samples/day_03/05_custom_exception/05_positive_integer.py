number = input("Enter number: ")

# Make an Error for input that cannot convert to a number
# Make an Error for input that is not a positive number
# Make an Error for input that is not a whole number