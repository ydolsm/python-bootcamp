import tkinter

# Create the main window
root = tkinter.Tk()

# Run the application
root.mainloop()