import tkinter

# Create the main window
root = tkinter.Tk()

# Setup main window title
root.title("Sample GUI Application")

# Run the application
root.mainloop()
