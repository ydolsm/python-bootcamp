import tkinter

# Create the main window
root = tkinter.Tk()

# Setup main window title
root.title("Sample GUI Application")

# Set window size
root.geometry("1200x400")

# Run the application
root.mainloop()
