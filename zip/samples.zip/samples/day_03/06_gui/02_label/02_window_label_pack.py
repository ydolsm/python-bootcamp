import tkinter

# Create the main window
root = tkinter.Tk()

# Create a label
label = tkinter.Label(root, text="Hello")
label.pack()

# Create a label
next_label = tkinter.Label(root, text="World")
next_label.pack()

# Run the application
root.mainloop()
