"""
Make a window that displays a haiku. If you can't think of one, here's an example:

Loops within loops spin,
A silent function returns,
The logic is clear.

"""