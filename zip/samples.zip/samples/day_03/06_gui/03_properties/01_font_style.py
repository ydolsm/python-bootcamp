import tkinter

# Create the main window
root = tkinter.Tk()

# Create a label
label = tkinter.Label(root, text="Hello", font=("Arial", 14, "bold italic"))
label.pack()

# Run the application
root.mainloop()