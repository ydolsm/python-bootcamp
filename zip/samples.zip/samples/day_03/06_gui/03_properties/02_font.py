import tkinter
from tkinter import font

root = tkinter.Tk()

all_fonts = font.families()
print(all_fonts)