import tkinter

# Create the main window
root = tkinter.Tk()

# Create a label
label = tkinter.Label(root, text="Hello!", fg="red", bg="yellow")
label.pack()

# Run the application
root.mainloop()
