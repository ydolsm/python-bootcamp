import tkinter
from tkinter import messagebox

# Set up the main window
root = tkinter.Tk()

# Trigger the messagebox directly
messagebox.showwarning("Warning", "This is a warning message.")

root.mainloop()
