from openpyxl import Workbook


workbook = Workbook()


workbook.save("sample.xlsx")
