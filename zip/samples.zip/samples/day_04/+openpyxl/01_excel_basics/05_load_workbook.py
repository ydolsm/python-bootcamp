from openpyxl import load_workbook


workbook = load_workbook("sample.xlsx")
