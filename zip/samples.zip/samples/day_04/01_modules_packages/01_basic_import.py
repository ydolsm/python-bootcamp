import hello

hello.say_hello()