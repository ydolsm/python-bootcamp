import hello as ho

ho.say_hello()