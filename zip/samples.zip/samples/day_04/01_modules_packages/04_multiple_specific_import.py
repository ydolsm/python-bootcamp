from hello import say_hello, greeting

say_hello()
print(greeting)