from hello import *

print(say_hello())
print(greeting)