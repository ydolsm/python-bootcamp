import package.module01 as pm1

pm1.say_hello()
