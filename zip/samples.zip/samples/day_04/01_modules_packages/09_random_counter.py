# Create one million random numbers from one to one thousand.
random_numbers = []

# List down the number of occurrence for each number
random_number_count = dict()

# Finally, print out the number with the highest count and how many times it appeared
