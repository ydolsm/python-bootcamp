def say_hello():
	print("Hello from module hello")

greeting = "Yellow!"

variable = 5