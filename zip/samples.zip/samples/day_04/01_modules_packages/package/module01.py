"""This module has a function `say_hello()`"""

def say_hello():
    print("Hello from module 1!")