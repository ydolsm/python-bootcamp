"""Module 02"""

def say_goodbye():
    print("Goodbye from module 2!")