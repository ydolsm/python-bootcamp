"""
def triple(x):
    return x * 3


print(triple(4))
"""

triple = lambda x: x * 3
print(triple(4))
