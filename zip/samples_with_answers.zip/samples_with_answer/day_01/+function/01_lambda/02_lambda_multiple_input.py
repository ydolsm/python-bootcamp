"""
def product(x, y):
    return x*y


print(product(2, 4))
"""

product = lambda x, y: x * y
print(product(2, 4))
