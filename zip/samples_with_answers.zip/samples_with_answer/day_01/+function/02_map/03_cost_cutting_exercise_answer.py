# Divide every item in the given cost by two

cost = [10_000, 200, 31, 45, 1]
cost_half = filter(lambda x: x / 2, cost)
print(list(cost_half))
