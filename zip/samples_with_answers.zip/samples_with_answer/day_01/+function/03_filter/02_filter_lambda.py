numbers = [1, 2, 3, 4, 5]
numbers_even = filter(lambda x: x % 2 == 0, numbers)
print(list(numbers_even))
