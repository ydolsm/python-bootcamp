# Change the list of score to only keep the ones greater than 6

scores = [10, 7, 5, 3, 5, 8]
scores_top = filter(lambda x: x > 6, scores)
print(list(scores_top))
