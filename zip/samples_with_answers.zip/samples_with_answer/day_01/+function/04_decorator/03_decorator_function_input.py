def check_authentication(function):

    def wrapper(user):
        if user != "admin":
            print("Access denied!")
        else:
            function(user)

    return wrapper


@check_authentication
def access_database(user):
    print("Accessing database...")


access_database("user")
access_database("admin")
