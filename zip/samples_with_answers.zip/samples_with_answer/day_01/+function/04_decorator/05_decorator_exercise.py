"""
Create a decorator to change the behavior of the following functions:

>>> Command: user input 1
You inputted user input 1

>>> User: user input 2
You inputted user input 2
"""


def console_input(function):
    def wrapper(*args, **kwargs):

        # Left-side effect
        print(">>>", end=" ")

        # Get input
        user_input = function()

        # Print input
        print("You inputted", user_input)

    return wrapper


@console_input
def get_command():
    return input("Command: ")


@console_input
def get_user():
    return input("User: ")


get_command()
get_user()
