count = 0
count_complete = False

# Based on the command, add by one, subtract by one, or end
while not count_complete:
    command = input("Command (up, down): ")
    match command:
        case "up":
            count += 1
            print(f"Count change ^: {count-1} -> {count}")
        case "down":
            count -= 1
            print(f"Count change v: {count+1} -> {count}")
        case _:
            print("Unknown command. Ending...")
            count_complete = True

print("Final count:", count)
