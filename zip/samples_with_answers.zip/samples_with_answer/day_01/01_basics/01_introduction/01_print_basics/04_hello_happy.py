print("I", "am", "happy")
