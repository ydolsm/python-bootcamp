# Practice for printing in multiple lines
print("Hello, I am new to Python")
print("Let’s learn together!")