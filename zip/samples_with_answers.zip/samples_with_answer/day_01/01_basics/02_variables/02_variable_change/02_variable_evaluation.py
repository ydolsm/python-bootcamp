age = 30
print(age)

age = age + 1
print(age)