result = 9999

# Change to result + 1 then print
result = result + 1
print(result)

# Change to result * 3 then print
result = result * 3
print(result)