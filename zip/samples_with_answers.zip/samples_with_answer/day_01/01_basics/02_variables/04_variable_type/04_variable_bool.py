is_raining = True
has_read_hair = False