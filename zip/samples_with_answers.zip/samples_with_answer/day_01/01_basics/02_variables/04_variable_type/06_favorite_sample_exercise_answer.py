# Your favorite food’s name
favorite_food_name = "Fried Chicken and Rice"

# How much does it usually cost to make it?
favorite_food_price = "90"

# Is it a type of food that’s homemade?
is_homemade = "Yes"