cause = "It's been raining in Manila"
# Print data type

cold = False
# Print data type

hard = 1
# Print data type