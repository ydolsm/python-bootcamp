cause = "It's been raining in Manila"
print(type(cause))

cold = False
print(type(cold))

hard = 1
print(type(hard))