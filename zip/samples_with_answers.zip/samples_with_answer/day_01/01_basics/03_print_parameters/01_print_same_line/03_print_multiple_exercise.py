# Your name here
user_name = None

# Favorite Number
favorite_number = None

# Favorite Color
favorite_color = None

# Print the following:
# Hello, my name is: user_name
# My favorite number is: favorite_number
# My favorite color is: favorite_color