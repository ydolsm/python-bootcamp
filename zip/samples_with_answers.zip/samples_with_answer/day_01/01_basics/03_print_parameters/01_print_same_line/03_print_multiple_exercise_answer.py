# Your name here
user_name = "Brad Pitt"

# Favorite Number
favorite_number = 1

# Favorite Color
favorite_color = "Black"

print("Hello, my name is:", user_name)
print("My favorite number is:", favorite_number)
print("My favorite color is:", favorite_color)