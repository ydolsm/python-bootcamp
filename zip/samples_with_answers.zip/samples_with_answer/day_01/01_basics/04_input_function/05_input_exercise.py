# Use the input() function to ask the user for the following details

# Username
user_name = None

# Favorite Number
favorite_number = None

# Favorite Color
favorite_color = None

# Then, print the following
# Hello, my name is: Your name here
# My favorite number is: favorite number
# My favorite color is: favorite color