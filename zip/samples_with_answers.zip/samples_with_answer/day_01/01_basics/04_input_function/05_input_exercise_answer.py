# Use the input() function to ask the user for the following details

# Username
user_name = input("Enter your name: ")

# Favorite Number
favorite_number = input("Enter your name: ")

# Favorite Color
favorite_color = input("Enter your name: ")

# Then, print the following
print("Hello, my name is:", user_name)
print("My favorite number is:", favorite_number)
print("My favorite color is:", favorite_color)
