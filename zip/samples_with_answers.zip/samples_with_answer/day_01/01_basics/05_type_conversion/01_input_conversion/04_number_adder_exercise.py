# Ask for two number inputs
first_number = None
second_number = None

# Print the sum of the two numbers in the console