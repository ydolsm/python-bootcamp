# Ask for two number inputs
first_number = int(input("Enter the first number: "))
second_number = int(input("Enter the second number: "))

# Print the sum of the two numbers in the console
print(first_number + second_number)