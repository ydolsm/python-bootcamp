# Addition
result = 11 + 2
print(result)

# Subtraction
result = 11 - 2
print(result)

# Multiplication
result = 11 * 2
print(result)

# Division
result = 11 / 2
print(result)