# Initial Value
result = 10
print(result)

# Equivalent to:
# result = result + 5
result += 5
print(result)

# Equivalent to:
# result = result / 5
result /= 5
print(result)