counter = 0
print(counter)

# Change the counter to counter plus one and print it
counter += 1
print(counter)

# Change the counter to counter minus one and print it
counter -= 1
print(counter)