# Ask for the following inputs:

# Weight in kilograms
weight = None

# Foot part of the height
height_foot = None

# Inches part of the height
height_inches = None

# Calculate the BMI using the following formula and print the result
#
#        /           weight [kg]            \  2
# BMI = | ---------------------------------- |
#        \ ((feet x 12) + inches) * 0.0254  /