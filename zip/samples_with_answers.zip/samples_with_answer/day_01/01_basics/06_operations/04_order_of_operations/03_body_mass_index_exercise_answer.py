# Ask for the following inputs:

# Weight in kilograms
weight = int(input("Weight [kg]: "))

# Foot part of the height
height_foot = int(input("Height [foot]: "))

# Inches part of the height
height_inches = int(input("Height [inches]: "))

# Calculate the BMI using the following formula and print the result
#
#        /           weight [kg]            \  2
# BMI = | ---------------------------------- |
#        \ ((feet x 12) + inches) * 0.0254  /

bmi = (weight / (((height_foot * 12) + height_inches) * 0.0254)) ** 2
print(bmi)