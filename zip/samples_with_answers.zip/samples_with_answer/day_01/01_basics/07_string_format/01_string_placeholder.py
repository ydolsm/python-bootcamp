message = "Hello {}! Nice to meet you!"

name = input("Enter your name: ")
formatted_message = message.format(name)
print(formatted_message)