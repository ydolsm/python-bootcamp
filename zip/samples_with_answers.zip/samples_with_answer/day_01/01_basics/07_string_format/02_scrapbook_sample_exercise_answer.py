# Placeholder messages
name_message = "Your name is {}."
number_message = "Your favorite number is {}."
color_message = "Your favorite color is {}."

# Ask the user for their inputs
user_name = input("Enter your name: ")
favorite_number = input("Enter your favorite number: ")
favorite_color = input("Enter your favorite color: ")

# Print the template with the placeholders replaced
print(name_message.format(user_name))
print(number_message.format(favorite_number))
print(color_message.format(favorite_color))