message = "Hello {} / {}"

name = input("Enter your name: ")
nickname = input("Enter your nickname: ")

print(message.format(name, nickname))