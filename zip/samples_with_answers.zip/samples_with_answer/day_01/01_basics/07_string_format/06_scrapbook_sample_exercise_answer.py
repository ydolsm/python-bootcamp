# Ask the user for their inputs
user_name = input("Enter your name: ")
favorite_number = input("Enter your favorite number: ")
favorite_color = input("Enter your favorite color: ")

print(f"Hello, my name is: {user_name}. That’s a nice name!")
print(f"My favorite number is: {favorite_number}. Nice choice.")
print(f"My favorite color is: {favorite_color}. Hopefully we see it today.")