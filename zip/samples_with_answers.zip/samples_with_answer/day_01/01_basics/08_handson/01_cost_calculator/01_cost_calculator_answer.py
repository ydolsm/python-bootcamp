# Ask the user for the information of three items
item_1_price = int(input("Enter item 1 price: "))
item_2_price = int(input("Enter item 2 price: "))
item_3_price = int(input("Enter item 3 price: "))

# Calculate the total cost
total_cost = item_1_price + item_2_price +item_3_price

# Print total cost
print(f"Total Cost: {total_cost}")