# Ask the user for the information of three items
item_1_price = int(input("Enter item 1 price: "))
item_1_count = int(input("Enter item 1 count: "))

item_2_price = int(input("Enter item 2 price: "))
item_2_count = int(input("Enter item 1 count: "))

item_3_price = int(input("Enter item 3 price: "))
item_3_count = int(input("Enter item 1 count: "))

# Replace None with total cost
total_cost = (
    (item_1_price * item_1_count)
    + (item_2_price * item_2_count)
    + (item_3_price * item_3_count)
)

# Print total cost
print(f"Total Cost: {total_cost}")