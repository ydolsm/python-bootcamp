# Ask the user for a message
message = input("Input message: ")

# Ask the user for a number
message_count = int(input("Repeat count for message: "))

# Ask the user for a number
line_count = int(input("Repeat count for line: "))

line = (message + " ") * message_count + "\n"
output = line * line_count

print(output)