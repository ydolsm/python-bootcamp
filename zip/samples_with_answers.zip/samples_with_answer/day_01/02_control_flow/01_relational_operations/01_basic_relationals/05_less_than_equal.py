number_1 = int(input("First Number: "))
number_2 = int(input("Second Number: "))

print(number_1 <= number_2)