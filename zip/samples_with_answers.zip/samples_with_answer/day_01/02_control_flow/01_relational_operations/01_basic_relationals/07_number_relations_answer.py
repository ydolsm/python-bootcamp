# Replace each None with an integer input
first_number = int(input("First Number: "))
second_number = int(input("Second Number: "))

# Print the result of the >, <, ==, and != operations on both
print(first_number > second_number)
print(first_number < second_number)
print(first_number == second_number)
print(first_number != second_number)