number_1 = 30
number_2 = int(input("Enter a number: "))
number_3 = 10

print(number_1 >= number_2 >= number_3)