# Replace each None with an integer input
min_number = int(input("Minimum Number: "))
max_number = int(input("Maximum Number: "))
number = int(input("Number: "))

# Print True or False depending on if number is in between the two numbers (inclusive)
print(min_number <= number <= max_number)