first = "Hello"
second = "World"

print(first == second)