logged_in = input("Are you logged in?: ")

if logged_in == "Yes":
    print("Welcome")
    print("Back")

print("End")