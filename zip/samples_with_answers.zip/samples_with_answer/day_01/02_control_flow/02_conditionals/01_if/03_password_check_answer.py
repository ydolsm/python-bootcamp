correct_password = "pass"
password_input = input("Please provide a password: ")

# Print "Access Granted" if password is correct
if password_input == correct_password:
    print("Access Granted!")