# Ask the user input for a color
color_input = input("Please enter a color: ")

if color_input == "green":
    print("Go!")
elif color_input == "yellow":
    print("Wait...")
elif color_input == "Red":
    print("Stop!")
else:
    print("Malfunction")