# Given the following variables
has_government_id = False
has_nbi_clearance = False
has_registered = False

# Then print the following if all variables are True
#   "Processing finished"
