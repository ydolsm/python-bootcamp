# Given the following variables
has_government_id = False
has_nbi_clearance = False
has_registered = False

if has_government_id == True and has_nbi_clearance == True and has_registered == True:
    print("Processing finished")
