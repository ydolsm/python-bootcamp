# Ask the user for a number
number = int(input("Provide a number: "))

if number == 0 or number == 1 or number == 10:
    print("Special Number Detected!")
else:
    print("Not a Special Number!")