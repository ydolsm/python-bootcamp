print(not True)
print(not False)