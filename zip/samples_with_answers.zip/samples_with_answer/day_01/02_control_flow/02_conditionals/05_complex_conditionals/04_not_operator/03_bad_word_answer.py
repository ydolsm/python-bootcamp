# Create a variable with the word the user shouldn’t give
bad_word = "ice cream"

# Then ask the user for an input
user_input = input("Please provide any input: ")

if not bad_word == user_input:
    print("That's a good word!")
else:
    print("That's a bad word!")