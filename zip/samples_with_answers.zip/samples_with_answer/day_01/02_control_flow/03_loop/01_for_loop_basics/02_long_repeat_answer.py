for _ in range(11):
    print("This is a very long line that can take some time for you to type.")