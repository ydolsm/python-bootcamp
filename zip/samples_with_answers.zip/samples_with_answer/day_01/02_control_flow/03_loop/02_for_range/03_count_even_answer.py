for number in range(50+1):
    print(number*2)