for item in range(95, 100+1):
	print(item)