for item in range(8, 1, -2):
    print(item)