for number in range(5, 100+1, 5):
    print(number)