counter = 0

while True:
    counter = counter + 1
    print(counter)