for item in range(100):
	user_input = input("Stop? (y/n) ")

	# End loop if user input is "y"
	if user_input == "y":
		break

	print(item)