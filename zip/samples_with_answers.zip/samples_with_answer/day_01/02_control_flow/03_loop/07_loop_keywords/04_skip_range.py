for item in range(100):

    # Skip numbers 20 to 80 (inclusive)



	print(item)