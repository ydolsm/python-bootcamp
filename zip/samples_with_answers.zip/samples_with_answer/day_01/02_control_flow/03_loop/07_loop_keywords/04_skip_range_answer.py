for item in range(100):
    
    # Skip numbers 20 to 80 (inclusive)
    if 20 <= item <= 80:
        continue

    print(item)