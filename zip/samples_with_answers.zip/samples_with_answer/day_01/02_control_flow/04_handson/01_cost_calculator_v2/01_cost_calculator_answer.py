# Ask the user for the number of items to get price:
item_count = int(input("Enter number of items: "))

# Then, depending on the item_count, keep asking for that many item price:
total_cost = 0
for _ in range(item_count):
    current_price = int(input("Input item price: "))
    total_cost += current_price

# Print the final cost
print(f"Total cost: {total_cost}")