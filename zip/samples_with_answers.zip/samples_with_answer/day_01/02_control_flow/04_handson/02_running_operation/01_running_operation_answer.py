# Get initial number
number = int(input("Enter initial number: "))
print(f"Initial number: {number}")

# Flags to check current state
end_program = False

# Start the process to ask for operation first
ask_operation = True
ask_number = False

# Store values (start as None)
current_operation = None
current_number = None

while not end_program:

    if ask_operation:
        current_operation = input("Enter operation: ")
        if current_operation == "exit":
            end_program = True
            break

        # Set next process
        ask_operation = False
        ask_number = True

    elif ask_number:
        current_number = input("Enter number: ")

        if current_number == "exit":
            end_program = True
            break

        current_number = int(current_number)

        if current_operation == "+":
            number += current_number
        elif current_operation == "-":
            number -= current_number
        elif current_operation == "*":
            number *= current_number
        elif current_operation == "//":
            number //= current_number

        print(f"Updated number: {number}")

        # Set next process
        ask_operation = True
        ask_number = False