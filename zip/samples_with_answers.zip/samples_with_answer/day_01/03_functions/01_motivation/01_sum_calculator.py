numbers = [1, 3, 5, 7, 2, 4, 6]

total = 0
for number in numbers:
    total += total

print(total)

new_numbers = [9, 3, 0, 1, 2, 7]

total_2 = 0
for number in numbers:
    total_2 += number

print(total_2)


