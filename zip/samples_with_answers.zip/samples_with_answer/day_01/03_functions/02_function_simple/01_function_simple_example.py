# Function definition
def greet():
	print("Hello, good day to you!")

# Function use
greet()