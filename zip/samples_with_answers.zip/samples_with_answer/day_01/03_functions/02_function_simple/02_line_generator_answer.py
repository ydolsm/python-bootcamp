def line_generator():
    for item in range(3):
        print(f"Line {item}")

line_generator()
line_generator()
line_generator()