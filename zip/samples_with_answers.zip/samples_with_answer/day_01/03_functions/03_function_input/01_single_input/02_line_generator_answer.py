def line_generator(line_count):
    for item in range(line_count):
        print(f"Line {item}")

line_generator(4)