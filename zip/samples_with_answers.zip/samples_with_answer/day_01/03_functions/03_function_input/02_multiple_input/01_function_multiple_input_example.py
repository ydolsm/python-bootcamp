def greet(username, message):
	print(f"Hello {username}, {message}")

greet("Joseph", "Nice to meet you!")