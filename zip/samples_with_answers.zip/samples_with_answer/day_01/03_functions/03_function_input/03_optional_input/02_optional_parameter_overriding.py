def greet(username, message="Nice to meet you!"):
	print(f"Hello {username}, {message}")

greet(username="Joseph", message="Hajimemashite!")