def line_generator(line_count=1, message="Hello World"):
    for item in range(line_count):
        print(f"{message} {item}")

line_generator()