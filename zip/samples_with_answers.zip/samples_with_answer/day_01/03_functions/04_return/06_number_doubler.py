def double(number):
	# Define the code here to return twice the number
	pass

x = 3
print(double(x))