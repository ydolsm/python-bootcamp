def double(number):
	# Define the code here to return twice the number
	return number * 2

x = 3
print(double(x))