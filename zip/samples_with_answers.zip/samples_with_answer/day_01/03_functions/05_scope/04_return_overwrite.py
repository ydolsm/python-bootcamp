x = 10

def function(x):
	x = 5
	return x

print(x)
x = function(x)
print(x)