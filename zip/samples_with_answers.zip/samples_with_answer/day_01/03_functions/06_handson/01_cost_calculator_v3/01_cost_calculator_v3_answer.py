def get_number_items():
    """Ask number for a valid positive number and return (int)"""
    number = int(input("Enter positive number: "))
    return number

def get_item_prices(repeat):
    """Ask the user for item prices repeat times and return total (int)"""

    total_price = 0
    for item in range(repeat):
        price = int(input("Enter item price: "))
        total_price = total_price + price

    return total_price

def display(total_price):
    """Print a message about the total_price"""
    print(f"Total Price: {total_price}")

def main():
    number_of_items = get_number_items()
    total = get_item_prices(number_of_items)
    display(total)

main()