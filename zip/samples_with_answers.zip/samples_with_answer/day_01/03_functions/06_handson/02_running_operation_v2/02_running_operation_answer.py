def get_initial_number():
    """Get initial number"""
    number = int(input("Enter initial number: "))
    print(f"Initial number: {number}")

    return number

def calculate(current_operation, current_number, number):
    if current_operation == "+":
        result = number + current_number
    elif current_operation == "-":
        result =  number - current_number
    elif current_operation == "*":
        result = number * current_number
    elif current_operation == "//":
        result = number // current_number

    return result


def main():

    number = get_initial_number()

    # Flags to check current state
    end_program = False

    # Start the process to ask for operation first
    ask_operation = True
    ask_number = False

    # Store values (start as None)
    current_operation = None
    current_number = None

    while not end_program:

        if ask_operation:
            current_operation = input("Enter operation: ")

            if current_operation == "exit":
                end_program = True
                break

            # Set next process
            ask_operation = False
            ask_number = True

        elif ask_number:
            current_number = input("Enter number: ")

            if current_number == "exit":
                end_program = True
                break

            current_number = int(current_number)
            number = calculate(current_operation, current_number, number)

            print(f"Updated number: {number}")

            # Set next process
            ask_operation = True
            ask_number = False

main()