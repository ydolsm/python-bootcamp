try:
    number_input = int(input("Type any number in the console: "))
    print(number_input)
except ValueError:
    print("You did not give a valid input")