raise ValueError("Custom message here")
