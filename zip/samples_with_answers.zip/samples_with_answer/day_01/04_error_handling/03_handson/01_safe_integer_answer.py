number = input("Enter number: ")

try:
    number_converted = int(number)
except ValueError:
    print("Invalid input. Please provide a valid integer")