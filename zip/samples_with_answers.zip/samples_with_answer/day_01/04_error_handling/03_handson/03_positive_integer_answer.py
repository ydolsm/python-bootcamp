number = input("Enter number: ")

try:
    number_converted = int(number)

    if number_converted < 0:
        raise TypeError()

except ValueError:
    print("Invalid input. Please provide a valid integer")
except TypeError:
    print("Invalid input. Please provide a positive integer")