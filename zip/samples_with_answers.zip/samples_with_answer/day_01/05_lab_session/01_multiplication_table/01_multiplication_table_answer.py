main_number = int(input("Enter a number: "))

for number in range(1, 11):
    print(f"{main_number} x {number} = {main_number * number}")
