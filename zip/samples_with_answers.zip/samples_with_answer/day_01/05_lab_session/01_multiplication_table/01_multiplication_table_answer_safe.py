
valid_input = False

while not valid_input:
    try:
        user_input = input("Enter a number: ")
        main_number = int(user_input)
        valid_input = True
    except ValueError:
        print(f"Input '{user_input}' is not a valid number! Try again.")

for number in range(1, 11):
    print(f"{main_number} x {number} = {main_number * number}")
