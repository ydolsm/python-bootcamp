def fizz_buzz() -> None:
    """
    Prints the numbers from 1 to 100. For multiples of 3, prints 'Fizz' instead of the number.
    For multiples of 5, prints 'Buzz' instead. For numbers that are multiples of both 3 and 5, prints 'FizzBuzz'.
    """
    for number in range(1, 101):
        if number % 3 == 0 and number % 5 == 0:
            print("FizzBuzz")
        elif number % 3 == 0:
            print("Fizz")
        elif number % 5 == 0:
            print("Buzz")
        else:
            print(number)

fizz_buzz()