from random import choice

def rock_win(choice1, choice2):
    return choice1 == "rock" and choice2 == "scissors"

def scissor_win(choice1, choice2):
    return choice1 == "scissors" and choice2 == "paper"

def paper_win(choice1, choice2):
    return choice1 == "paper" and choice2 == "rock"

def winner(choice1, choice2):
    return (
        rock_win(choice1, choice2)
        or scissor_win(choice1, choice2)
        or paper_win(choice1, choice2)
    )

def quick_draw_round():
    # Ask the user for an input
    user_choice = input("Pick a choice (rock/paper/scissors): ")

    # Select a choice for the CPU
    options = ["rock", "paper", "scissors"]
    cpu_choice = choice(options)

    print(f"CPU picked {cpu_choice}")

    if winner(user_choice, cpu_choice):
        print("You Win!")
    elif winner(cpu_choice, user_choice):
        print("You Lost!")
    else:
        print("Draw!")

quick_draw_round()