from random import choice

def get_valid_choice():

    valid_input = False
    user_choice = None

    while not valid_input:
        user_choice = input("Pick a choice (rock/paper/scissors): ")

        if user_choice != "rock" and user_choice != "paper" and user_choice != "scissors":
            print(f"User choice '{user_choice}' is not valid!")
        else:
            valid_input = True

    return user_choice

def rock_win(choice1, choice2):
    return choice1 == "rock" and choice2 == "scissors"

def scissor_win(choice1, choice2):
    return choice1 == "scissors" and choice2 == "paper"

def paper_win(choice1, choice2):
    return choice1 == "paper" and choice2 == "rock"

def winner(choice1, choice2):
    return (
        rock_win(choice1, choice2)
        or scissor_win(choice1, choice2)
        or paper_win(choice1, choice2)
    )

def quick_draw_round():
    # Ask the user for an input
    user_choice = get_valid_choice()

    # Select a choice for the CPU
    options = ["rock", "paper", "scissors"]
    cpu_choice = choice(options)

    print(f"CPU picked {cpu_choice}")

    if winner(user_choice, cpu_choice):
        print("You Win!")
    elif winner(cpu_choice, user_choice):
        print("You Lost!")
    else:
        print("Draw!")

quick_draw_round()