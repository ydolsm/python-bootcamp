from random import choice

def get_valid_positive_number(message):

    valid_input = False
    number = None

    while not valid_input:
        user_input = input(message)

        try:
            number = int(user_input)

            if number < 0:
                raise TypeError()

            valid_input = True

        except ValueError:
            print(f"Input '{user_input}' is not a valid number!")
        except TypeError:
            print(f"Input '{user_input}' is not positive!")

    return number

def get_valid_choice():

    valid_input = False
    user_choice = None

    while not valid_input:
        user_choice = input("Pick a choice (rock/paper/scissors): ")

        if user_choice != "rock" and user_choice != "paper" and user_choice != "scissors":
            print(f"User choice '{user_choice}' is not valid!")
        else:
            valid_input = True

    return user_choice

def rock_win(choice1, choice2):
    return choice1 == "rock" and choice2 == "scissors"

def scissor_win(choice1, choice2):
    return choice1 == "scissors" and choice2 == "paper"

def paper_win(choice1, choice2):
    return choice1 == "paper" and choice2 == "rock"

def winner(choice1, choice2):
    return (
        rock_win(choice1, choice2)
        or scissor_win(choice1, choice2)
        or paper_win(choice1, choice2)
    )


def quick_draw_round():
    # Ask the user for an input
    user_choice = get_valid_choice()

    # Select a choice for the CPU
    options = ["rock", "paper", "scissors"]
    cpu_choice = choice(options)

    print(f"CPU picked {cpu_choice}")

    if winner(user_choice, cpu_choice):
        print("You Win!")
        return 'user'
    elif winner(cpu_choice, user_choice):
        print("You Lost!")
        return 'cpu'
    else:
        print("Draw!")
        return 'draw'

def main():

    user_wins = 0
    cpu_wins = 0

    wins_required = get_valid_positive_number("Enter number of rounds to win: ")

    while user_wins < wins_required and cpu_wins < wins_required:
        round_winner = quick_draw_round()

        if round_winner == "cpu":
            cpu_wins += 1
        elif round_winner == "user":
            user_wins += 1

        print("Current state:")
        print(f"\tUser: {user_wins}")
        print(f"\tCPU: {cpu_wins}")

    if user_wins > cpu_wins:
        print("User wins in total")
    else:
        print("User loses in total")

main()