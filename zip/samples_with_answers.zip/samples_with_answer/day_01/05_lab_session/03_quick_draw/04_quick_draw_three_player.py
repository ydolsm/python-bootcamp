from random import choice

def rock_win(choice1, choice2):
    return choice1 == "rock" and choice2 == "scissors"

def scissor_win(choice1, choice2):
    return choice1 == "scissors" and choice2 == "paper"

def paper_win(choice1, choice2):
    return choice1 == "paper" and choice2 == "rock"

def winner(choice1, choice2):
    return (
        rock_win(choice1, choice2)
        or scissor_win(choice1, choice2)
        or paper_win(choice1, choice2)
    )

def get_valid_positive_number(message):

    valid_input = False
    number = None

    while not valid_input:
        user_input = input(message)

        try:
            number = int(user_input)

            if number < 0:
                raise TypeError()

            valid_input = True

        except ValueError:
            print(f"Input '{user_input}' is not a valid number!")
        except TypeError:
            print(f"Input '{user_input}' is not positive!")

    return number

def get_valid_choice():

    valid_input = False
    user_choice = None

    while not valid_input:
        user_choice = input("Pick a choice (rock/paper/scissors): ")

        if user_choice != "rock" and user_choice != "paper" and user_choice != "scissors":
            print(f"User choice '{user_choice}' is not valid!")
        else:
            valid_input = True

    return user_choice

def quick_draw_round():
    user1_choice = get_valid_choice()
    user2_choice = get_valid_choice()

    # Select a choice for the CPU
    options = ["rock", "paper", "scissors"]
    cpu_choice = choice(options)

    print(f"CPU picked {cpu_choice}")

    if winner(user1_choice, user2_choice) and winner(user1_choice, cpu_choice):
        print("User 1 Wins!")
        return "user 1"
    elif winner(user2_choice, user1_choice) and winner(user2_choice, cpu_choice):
        print("User 2 Wins!")
        return "user 2"
    elif winner(cpu_choice, user1_choice) and winner(cpu_choice, user2_choice):
        print("CPU Wins!")
        return "cpu"
    elif user1_choice == user2_choice and winner(user1_choice, cpu_choice):
        print("User 1 and User 2 Wins!")
        return "user 1 and user 2"
    elif user1_choice == cpu_choice and winner(user1_choice, user2_choice):
        print("User 1 and CPU Wins!")
        return "user 1 and cpu"
    elif user2_choice == cpu_choice and winner(user2_choice, user1_choice):
        print("User 2 and CPU Wins!")
        return "user 2 and cpu"
    # Includes three different choices and perfect draws
    else:
        print("Draw!")
        return "draw"

def main():

    user1_wins = 0
    user2_wins = 0
    cpu_wins = 0

    wins_required = get_valid_positive_number("Enter number of rounds to win: ")

    while user1_wins < wins_required and user2_wins < wins_required and cpu_wins < wins_required:
        round_winner = quick_draw_round()

        if round_winner == "cpu":
            cpu_wins += 1
        elif round_winner == "user 1":
            user1_wins += 1
        elif round_winner == "user 2":
            user2_wins += 1
        elif round_winner == "user 1 and user 2":
            user1_wins += 1
            user2_wins += 1
        elif round_winner == "user 1 and cpu":
            cpu_wins += 1
            user1_wins += 1
        elif round_winner == "user 2 and cpu":
            cpu_wins += 1
            user2_wins += 1

        print("Current state:")
        print(f"\tUser 1: {user1_wins}")
        print(f"\tUser 2: {user2_wins}")
        print(f"\tCPU: {cpu_wins}")

    if user1_wins > cpu_wins and user1_wins > user2_wins:
        print("User 1 wins in total")
    elif user2_wins > cpu_wins and user2_wins > user1_wins:
        print("User 2 wins in total")
    elif cpu_wins > user1_wins and cpu_wins > user2_wins:
        print("CPU wins in total")
    elif user1_wins == user2_wins and user1_wins > cpu_wins:
        print("It's a tie between User 1 and User 2!")
    elif user1_wins == cpu_wins and user1_wins > user2_wins:
        print("It's a tie between User 1 and CPU!")
    elif user2_wins == cpu_wins and user2_wins > user1_wins:
        print("It's a tie between User 2 and CPU!")

main()