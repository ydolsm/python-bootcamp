user_input = input("Enter short message: ")

# Remove all vowels
no_vowel_set = {...}

print(no_vowel_set)
