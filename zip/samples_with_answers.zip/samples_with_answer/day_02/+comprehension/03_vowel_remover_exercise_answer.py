user_input = input("Enter short message: ")

# Remove all vowels
no_vowel_set = {letter for letter in user_input if letter not in "aeiou"}

print(no_vowel_set)
