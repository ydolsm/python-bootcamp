pokemon = ["Pikachu", "Charmander", "Squirtle"]

dex = {p: f"{p} used {p[:4]}-Attack!" for p in pokemon}
