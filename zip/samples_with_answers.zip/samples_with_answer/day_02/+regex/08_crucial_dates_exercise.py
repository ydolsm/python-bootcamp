message = "The event is on 12/15/2023, and the deadline is 01/01/2024."

# Print all of the mentioned dates
print()
