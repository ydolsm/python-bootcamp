message = "I like apple pie; apple is my favorite fruit."

# Replace every instance of “apple” with “buko”
# "I like buko pie; buko is my favorite fruit."
print()
