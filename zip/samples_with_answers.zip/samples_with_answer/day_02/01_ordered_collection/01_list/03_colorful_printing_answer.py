# Replace None with your custom list of colors
colors = ['red', 'orange', 'yellow', 'green', 'blue', 'indigo', 'viloet']
print(colors)

# Then, print each color one line at a time
for color in colors:
    print(color)