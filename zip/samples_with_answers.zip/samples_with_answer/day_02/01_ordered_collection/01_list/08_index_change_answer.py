letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']

letters[0] = '*'
letters[2] = '*'
letters[4] = '*'

print(letters)