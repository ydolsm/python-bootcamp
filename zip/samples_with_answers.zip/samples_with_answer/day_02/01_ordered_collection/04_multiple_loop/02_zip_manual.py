items = ['a', 'b', 'c']
others = [1, 2, 3]

combined = zip(items, others)
print(list(combined))