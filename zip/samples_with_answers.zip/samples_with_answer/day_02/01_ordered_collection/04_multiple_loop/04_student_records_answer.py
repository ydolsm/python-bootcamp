student_names = ["Juan", "Maria", "Joseph"]
student_scores = [70, 90, 81]

print("Student Records:")

for name, score in zip(student_names, student_scores):
    print(f"\tRecord: {name} scored {score} in the exam.")

# Challenge
highest_score = 0
highest_scorer = ''
for name, score in zip(student_names, student_scores):
    if score > highest_score:
        highest_score = score
        highest_scorer = name

print(f'{highest_scorer} scored the highest with a score of {highest_score}')