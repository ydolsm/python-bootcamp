items = ["a", "b", "c"]
for index, item in enumerate(items):
    print(index, items)
