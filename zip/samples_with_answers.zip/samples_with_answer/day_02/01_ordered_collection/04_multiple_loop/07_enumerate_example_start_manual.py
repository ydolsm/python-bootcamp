items = ['a', 'b', 'c', 'd']

enumerated = enumerate(items)
print(list(enumerated))