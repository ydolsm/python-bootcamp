student_names = ["Juan", "Maria", "Joseph"]

# Print the student names in the following format:
# Attendance Log:
#   Student 1: Juan
# 	Student 2: Maria
# 	Student 3: Joseph