student_names = ["Juan", "Maria", "Joseph"]

print("Attendance Log:")

for number, name in enumerate(student_names, start=1):
    print(f"\tStudent {number}: {name}")