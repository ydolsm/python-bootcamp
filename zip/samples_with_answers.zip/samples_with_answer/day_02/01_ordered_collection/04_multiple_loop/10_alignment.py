names = ["Juan", "Maria", "Joseph"]
tasks = ["Task 1", "Task 2", "Task 3"]

# Print in the following format:
    # Juan - Task 1
    # Juan - Task 2
    # Juan - Task 3
    # Maria - Task 1
    # Maria - Task 2
    # Maria - Task 3
    # Joseph - Task 1
    # Joseph - Task 2
    # Joseph - Task