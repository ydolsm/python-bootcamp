names = ["Juan", "Maria", "Joseph"]
tasks = ["Task 1", "Task 2", "Task 3"]

# Print in the following format:
for name in names:
    for task in tasks:
        print(f"{name} - {task}")