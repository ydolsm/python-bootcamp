letters = [
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j',
    'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't',
    'u', 'v', 'w', 'x', 'y', 'z'
]

# Print the following slices
#   [‘a’, ‘b’, ‘c’]
#   [‘x’, ‘y’, ‘z’]
#   [‘h’, ‘i’, ‘j’, ‘k’, ‘l’]
print(letters[:3])
print(letters[-3:])
print(letters[7:12])