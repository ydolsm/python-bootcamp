letters = [
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j',
    'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't',
    'u', 'v', 'w', 'x', 'y', 'z'
]

# Print the following slices
#   [‘a’, ‘c’, ‘e’, ‘g’]
#   [‘b’, ‘g’, ‘l’, ‘q’]
print(letters[:7:2])
print(letters[1:17:5])