user_input = input("Proceed (Yes/yes/y)? ")

# if user_input == "Yes" or user_input == "yes" or user_input == "y"
if user_input in ("Yes", "yes", "y"):
	print("Proceeding")