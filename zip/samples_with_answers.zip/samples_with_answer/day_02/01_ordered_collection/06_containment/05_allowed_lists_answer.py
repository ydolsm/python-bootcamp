# Create a list of names
names = ["Name 1", "Name 2", "Name 3"]

# Then ask the user for an input
user_name = input("Please provide your name: ")

if user_name in names:
    print("Access Granted!")
else:
    print("Access Denied!")