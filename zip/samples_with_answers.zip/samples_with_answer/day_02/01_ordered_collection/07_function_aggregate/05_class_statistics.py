student_scores = [98, 75, 100, 86, 100, 3]

# Print the lowest, highest, and average score.


