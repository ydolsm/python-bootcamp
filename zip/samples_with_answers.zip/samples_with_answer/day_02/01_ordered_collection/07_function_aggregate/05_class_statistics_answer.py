student_scores = [98, 75, 100, 86, 100, 3]

# Print the lowest, highest, and average score.
print(f"Lowest Score: {min(student_scores)}")
print(f"Highest Score: {max(student_scores)}")
print(f"Average Score: {sum(student_scores) / len(student_scores)}")