example = [1, 3, 3, 5, 4]
other_example = [999, -1, 0]

example.extend(other_example)
print(example)

