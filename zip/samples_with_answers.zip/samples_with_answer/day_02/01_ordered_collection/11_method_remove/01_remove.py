example = [1, 3, 3, 5, 4]

example.remove(5)
print(example)
