example = [1, 3, 3, 5, 4]

removed_item = example.pop(-1)

print(removed_item)
print(example)