def add(song, playlist):
	"""Add song to playlist"""
	playlist.append(song)
	print(f"Song '{song}' added to playlist")

def remove(song, playlist):
	"""Remove song from playlist"""

	if song in playlist:
		playlist.remove(song)
		print(f"Song '{song}' removed from playlist")
	else:
		print(f"Warn: Song '{song}' not in playlist")

def play(playlist):
	"""Print the first song in the playlist (if any)"""

	if len(playlist) > 0:
		current_song = playlist.pop(0)
		print(f"Playing '{current_song}'...")
		print(f"Finished playing")
	else:
		print("Can't play: Playlist empty")

def show_all(playlist):
	"""Print all contents in the playlist"""

	if len(playlist) > 0:
		for index, song in enumerate(playlist, start=1):
			print(f"\t{index}.) {song}")
	else:
		print("Playlist empty")


def playlist_app():
	"""Ask user what command they want to do"""

	playlist = []
	finished = False

	while not finished:
		user_choice = input("Enter command (add/remove/play/show all/exit): ")

		if user_choice == "add":
			new_song = input("Enter new song: ")
			add(new_song, playlist)
		elif user_choice == "remove":
			song_to_remove = input("Enter song to remove: ")
			remove(song_to_remove, playlist)
		elif user_choice == "play":
			play(playlist)
		elif user_choice == "show all":
			show_all(playlist)
		elif user_choice == "exit":
			finished = True

playlist_app()