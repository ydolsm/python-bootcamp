def add(song, artist, playlist):
	"""Add song to playlist"""
	playlist.append((song, artist))
	print(f"Song '{song}' by '{artist}' added to playlist")

def remove(song, playlist):
	"""Remove song from playlist"""

	found_song = None

	for song_detail in playlist:
		song_name = song_detail[0]

		if song_name == song:
			found_song = song_detail
			break

	if found_song != None:
		playlist.remove(found_song)
		print(f"Song '{song}' removed from playlist")

		if len(playlist) == 0:
			print("Playlist now empty")
	else:
		print(f"Warn: Song '{song}' not in playlist")

def play(playlist):
	"""Print the first song in the playlist (if any)"""

	if len(playlist) > 0:
		current_song = playlist.pop(0)

		current_song_name = current_song[0]
		current_song_artist = current_song[1]

		print(f"Playing '{current_song_name}' by '{current_song_artist}'...")
		print(f"Finished playing")

	else:
		print("Playlist empty")

def show_all(playlist):
	"""Print all contents in the playlist"""

	if len(playlist) > 0:
		for index, song in enumerate(playlist, start=1):
			song_name = song[0]
			song_artist = song[1]

			print(f"\t{index}.) {song_name} [{song_artist}]")
	else:
		print("Playlist empty")


def playlist_app():
	"""Ask user what command they want to do"""

	playlist = []
	finished = False

	liner = "=" * 60

	print(liner)
	print(" Christmas Playlist")

	while not finished:
		print(liner)
		user_choice = input("Enter command (add/remove/play/show all/exit): ")
		print(liner)

		if user_choice == "add":
			new_song_name = input("Enter new song name: ")
			new_song_artist = input("Enter new song artist: ")
			add(new_song_name, new_song_artist, playlist)
		elif user_choice == "remove":
			song_to_remove = input("Enter song name to remove: ")
			remove(song_to_remove, playlist)
		elif user_choice == "play":
			play(playlist)
		elif user_choice == "show all":
			show_all(playlist)
		elif user_choice == "exit":
			finished = True

playlist_app()