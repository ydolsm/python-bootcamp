def make_matrix(row_count, col_count):

    matrix = []

    for row_number in range(1, row_count+1):

        row = []

        for col_number in range(1, col_count+1):
            row.append(row_number * col_number)

        matrix.append(row)

    return matrix

def display_matrix(matrix):
    if len(matrix) == 0 or len(matrix[0]) == 0:
        print("Empty matrix")
    else:
        print()

        for row in matrix:
            print('| ', end='')

            for element in row:
                print(f"\t{element}\t", end=" | ")

            print()

def main():
    try:
        row_count = int(input("Enter row count (default: 3): "))
    except ValueError:
        row_count = 3

    try:
        col_count = int(input("Enter col count (default: 5): "))
    except ValueError:
        col_count = 5

    new_matrix = make_matrix(row_count, col_count)
    display_matrix(new_matrix)

main()