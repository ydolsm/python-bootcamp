letters = {'a', 'a', 'b', 'c', 'd'}
print(letters)