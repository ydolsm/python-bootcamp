numbers = {1, 1, 2, 2, 3, 3}
print(numbers)