example = {1, 3, 5, 6}
print(example)

example.add(99)
print(example)