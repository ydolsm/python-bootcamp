attendee_names = set()

attendee_count = int(input("How many attendees? "))

for attendee in range(attendee_count):
    attendee_name = input("attendee name: ")
    attendee_names.add(attendee_name)

print(attendee_names)