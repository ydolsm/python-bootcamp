attendee_names = set()

attendee_count = int(input("How many attendees? "))

for attendee in range(attendee_count):
    attendee_name = input("attendee name: ")
    attendee_names.add(attendee_name)

print(attendee_names)

my_name = "Joseph"
attendee_names.discard(my_name)

for index, attendee in enumerate(attendee_names, start=1):
    print(f"Attendee {index}: {attendee}")