example = {1, 3, 5, 6}
print(example)

return_value = example.pop()
print(example)
print(return_value)