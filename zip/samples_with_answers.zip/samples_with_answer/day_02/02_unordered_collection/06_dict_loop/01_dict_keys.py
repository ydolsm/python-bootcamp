student_records = {
	"Juan": 70,
	"Maria": 98,
    "Joseph": 81,
    "Elise": 80,
}

for student_name in student_records.keys():
	print(student_name)