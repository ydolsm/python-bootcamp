# Using your favorites dict earlier, print each key in this format:
# My Favorites:
# 	number
# 	color