# Make a dictionary of your favorites (feel free to add more)
favorites = {
	"number": 2,
	"color": "black",
}

# Print the favorites dictionary
print("Favorites:")
for key in favorites.keys():
    print(f"\t{key}")
