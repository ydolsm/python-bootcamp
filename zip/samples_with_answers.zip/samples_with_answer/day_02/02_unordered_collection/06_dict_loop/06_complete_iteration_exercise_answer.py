# Make a dictionary of your favorites (feel free to add more)
favorites = {
	"number": 2,
	"color": "black",
}

# Print the favorites dictionary
print("Favorites:")

for key, value in favorites.items():
    print(f"\t{key}: {value}")
