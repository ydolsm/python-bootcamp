# Given the empty dictionary
attendees = dict()

# Ask the user for an integer
attendee_count = int(input("How many attendees? "))

# Based on the attendee_count, ask the user for that many attendee names and task
#   attendee name:
#   attendee task:
#   attendee name:
#   attendee task:
#   attendee name:
#   attendee task:
# ...

# Append each input in attendees and print attendees

