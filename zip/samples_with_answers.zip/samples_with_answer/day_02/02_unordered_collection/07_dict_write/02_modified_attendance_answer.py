# Given the empty dictionary
attendees = dict()

# Ask the user for an integer
attendee_count = int(input("How many attendees? "))

for attendee in range(attendee_count):
    attendee_name = input("attendee name: ")
    attendee_task = input("attendee task: ")

    attendees[attendee_name] = attendee_task

print(attendees)