student_records = {"Juan": 70, "Maria": 98, "Joseph": 100, "Elise": 80}

student_records["Joseph"] = 100
print(student_records["Joseph"])