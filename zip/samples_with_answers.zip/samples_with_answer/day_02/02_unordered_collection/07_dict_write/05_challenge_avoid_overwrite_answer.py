# Given the empty dictionary
attendees = dict()

# Ask the user for an integer
attendee_count = int(input("How many attendees? "))

for attendee in range(attendee_count):
    attendee_name = input("attendee name: ")

    if attendee_name in attendees.keys():
        print("This attendee has already been added! Skipping...")
    else:
        attendee_task = input("attendee task: ")
        attendees[attendee_name] = attendee_task

print(attendees)