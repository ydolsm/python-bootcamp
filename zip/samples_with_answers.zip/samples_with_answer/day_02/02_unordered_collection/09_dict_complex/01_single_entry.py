product_entry = {
   	'name': 'Smartphone',
    'description': 'Latest model smartphone.',
    'price': 999.99,
    'stock': 25
}