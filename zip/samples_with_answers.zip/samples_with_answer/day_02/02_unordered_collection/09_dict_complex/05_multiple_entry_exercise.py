# Make a dictionary for employee details
# Add more to the following:
employees = [
	{
        'name': 'John Doe',
        'role': 'Developer',
    }
]

for employee in employees:
    print()