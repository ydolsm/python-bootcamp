employees = [
    {
        'name': 'John Doe',
        'role': 'Developer',
        'age': 30,
        'department': 'IT',
        'skills': ['Python', 'JavaScript', 'SQL'],
        'experience_years': 5
    },
    {
        'name': 'Jane Smith',
        'role': 'Designer',
        'age': 28,
        'department': 'UI/UX',
        'skills': ['Figma', 'Photoshop', 'Sketch'],
        'experience_years': 3
    },
    {
        'name': 'Emily Johnson',
        'role': 'Project Manager',
        'age': 35,
        'department': 'Management',
        'skills': ['Agile', 'Scrum', 'Leadership'],
        'experience_years': 8
    }
]

line = "-" * 60

for employee in employees:
    print(line)
    print("Employee Details:")
    print(line)

    print(f"Name:\t\t{employee['name']}")
    print(f"Role:\t\t{employee['role']}")
    print(f"Age:\t\t{employee['age']}")
    print(f"Department:\t{employee['department']}")
    print(f"Skills:\t\t{employee['skills']}")
    print(f"Experience:\t{employee['experience_years']} years")

print(line)