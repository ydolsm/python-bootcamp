def add(name, price, quantity, cart):
	"""Add a dictionary with key name to cart"""

def remove(name, cart):
	"""Remove entry with key name from cart"""

def show_all(cart):
	"""Print all contents in cart"""

def show_total(cart):
	"""Calculate and print total of cart"""

def cart_app():
	"""Ask user what command they want to do"""

cart_app()