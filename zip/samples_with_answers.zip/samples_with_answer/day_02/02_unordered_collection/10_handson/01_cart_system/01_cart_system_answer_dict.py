def print_item_detail(name, quantity, price):
	print(f"\t'{name}' [PHP {price}] ({quantity}x)")

def add(name, quantity, price, cart):
	"""Add a dictionary with key name to cart"""

	# Adding item detail to cart
	cart[name] = {'name': name, 'price': price, 'quantity': quantity}

	# Print item detail
	print("Added:", end="")
	print_item_detail(name, quantity, price)

def remove(name, cart):
	"""Remove entry with key name from cart"""

	# Remove item from dict by pop
	if name in cart.keys():
		item = cart.pop(name)

		print("Removed:", end="")
		print_item_detail(name, item['quantity'], item['price'])
	else:
		print(f"Item '{name}' not in cart")

def show_all(cart):
	"""Print all contents in cart"""

	print("Cart Items:")
	for name, item in cart.items():
		print_item_detail(name, item["quantity"], item["price"])

def show_total(cart):
	"""Calculate and print total of cart"""

	total = 0
	for item in cart.values():
		item_total_price = item['price'] * item['quantity']
		total += item_total_price

	print(f"Cart Total: {total}")

def cart_app():
	"""Ask user what command they want to do"""

	cart = dict()
	finished = False

	while not finished:
		user_choice = input("Enter command (add/remove/show/total/exit): ")

		if user_choice == "add":
			name = input("Enter new item name: ")
			quantity = int(input("Enter new item quantity: "))
			price = int(input("Enter new item price: "))

			add(name, quantity, price, cart)

		elif user_choice == "remove":
			item_to_remove_name = input("Enter item to remove: ")
			remove(item_to_remove_name, cart)
		elif user_choice == "show":
			show_all(cart)
		elif user_choice == "total":
			show_total(cart)
		elif user_choice == "exit":
			finished = True

cart_app()