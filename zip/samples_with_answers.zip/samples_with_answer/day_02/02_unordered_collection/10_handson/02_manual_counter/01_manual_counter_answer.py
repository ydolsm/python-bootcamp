def counter(items):
    counts = dict()

    for item in items:
        counts[item] = items.count(item)

    return counts

# Try this example:
items = [1, 1, 2, 2, 2, 3]
item_count = counter(items)
print(item_count)