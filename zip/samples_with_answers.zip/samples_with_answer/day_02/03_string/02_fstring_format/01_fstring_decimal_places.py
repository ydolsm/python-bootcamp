number = 1.123456789
print(f"{number:.2f}")
