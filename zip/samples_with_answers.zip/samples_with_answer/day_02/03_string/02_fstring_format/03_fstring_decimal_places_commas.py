number = 123456.789
print(f"{number:,.2f}")
