number = 0.9899
print(f"{number:.2%}")
