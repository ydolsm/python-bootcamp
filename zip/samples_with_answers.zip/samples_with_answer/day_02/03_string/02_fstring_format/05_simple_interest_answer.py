print("=" * 40)

initial_balance = float(input("Enter initial balance: "))
time_years = float(input("Enter time (in years): "))
interest_rate = float(input("Enter interest rate: "))

print("=" * 40)

print(f"Initial Balance: PHP {initial_balance:,.2f}")
print(f"Time (in Years): {time_years:.4f}")
print(f"Interest Rate: {interest_rate:.4%}")

print("=" * 40)

simple_interest = initial_balance * (1 + interest_rate) * time_years
print(f"Simple Interest: PHP {simple_interest:,.2f}")

print("=" * 40)
