message = 'Hello World'
print('World' in message)

