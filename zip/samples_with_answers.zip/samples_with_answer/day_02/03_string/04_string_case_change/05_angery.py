# Given a user input, return the angry version of it:
#   Input: "I am perfectly calm and everything is fine"
#   Output: "I AM PERFECTLY CALM AND EVERYTHING IS FINE"