user_input = input("Enter a message: ")
print(user_input.upper())