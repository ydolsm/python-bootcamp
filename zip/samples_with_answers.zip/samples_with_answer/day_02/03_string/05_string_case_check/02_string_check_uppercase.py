example = "HELLO"

all_upper = example.isupper()
print(example)
print(all_upper)
