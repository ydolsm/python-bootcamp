# Given a regular string input, count the number of lowe case, upper case, and spaces

# Input: "I am perfectly calm and everything is fine"
#     Lower case count: 34
#     Upper case count: 1
#     Space case count: 7

