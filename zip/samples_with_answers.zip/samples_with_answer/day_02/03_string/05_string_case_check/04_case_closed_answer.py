user_input = input("Enter message: ")

lower_case_count = 0
upper_case_count = 0
space_case_count = 0

for character in user_input:
    if character.islower():
        lower_case_count += 1
    elif character.isupper():
        upper_case_count += 1
    elif character.isspace():
        space_case_count += 1

print(f"Lower case count: {lower_case_count}")
print(f"Upper case count: {upper_case_count}")
print(f"Space case count: {space_case_count}")