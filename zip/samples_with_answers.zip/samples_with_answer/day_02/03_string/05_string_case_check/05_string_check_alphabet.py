example = "Hello"

all_alpha = example.isalpha()
print(example)
print(all_alpha)

