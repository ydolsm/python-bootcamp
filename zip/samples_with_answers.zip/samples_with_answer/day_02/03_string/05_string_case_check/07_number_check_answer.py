user_input = input("Please provide any input: ")

if user_input.isnumeric():
    print("This is a valid number")
else:
    print( "This is not a valid number")