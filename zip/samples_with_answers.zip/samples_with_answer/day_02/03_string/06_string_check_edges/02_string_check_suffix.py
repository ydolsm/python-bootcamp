example = "Hello World"

worldly = example.endswith("World")
print(example)
print(worldly)