example = "        Hello World                 "

clean_example = example.rstrip()
print(f"'{example}'")
print(f"'{clean_example}'")