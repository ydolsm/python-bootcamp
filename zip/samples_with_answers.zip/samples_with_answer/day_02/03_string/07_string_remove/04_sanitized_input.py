user_input = input("Proceed (Yes/yes/y)? ")
clean_input = user_input.lower().strip()

if clean_input == "yes":
	print("Proceeding")