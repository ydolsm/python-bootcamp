user_input = input("Enter a number: ")
user_input = user_input.strip().replace(', ', '').replace(',', '')
print(f"'{user_input}'")

number = int(user_input)
print(number)