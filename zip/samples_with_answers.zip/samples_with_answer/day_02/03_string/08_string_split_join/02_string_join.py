example = ['Hello', 'I', 'am', 'a', 'message!']

combined_words = " ".join(example )
print(example)
print(combined_words)

