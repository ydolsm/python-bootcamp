user_input = input("Enter a message: ")

words = user_input.split()
combined_words = ' '.join(words)

print(combined_words)