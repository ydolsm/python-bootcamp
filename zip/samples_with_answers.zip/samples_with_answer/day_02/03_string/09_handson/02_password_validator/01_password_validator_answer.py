def valid_password(password):
    """Returns True if the given password satisfies the following conditions:
        - Password is at least six characters long but not more than 20 characters
        - Password has at least one number
        - Password has an uppercase and lowercase letter
        - Password has at least one special character
        - Password does not contain the word "pass"
    """

    # Check if the password length is between 6 and 20 characters
    if len(password) < 6 or len(password) > 20:
        return False

    has_number = False
    has_upper = False
    has_lower = False
    has_special = False
    for char in password:
        if char.isdigit():
            has_number = True
        elif char.isupper():
            has_upper = True
        elif char.islower():
            has_lower = True
        elif not char.isspace():
            has_special = True

    # Check if all conditions are met
    if not has_number or not has_upper or not has_lower or not has_special:
        return False

    # Check if the password contains the word "pass"
    if 'pass' in password.lower():
        return False

    return True