with open("test.txt", "w") as file:
	file.write("New Line")
