attendees = [
    "Mia Anderson",
    "Ethan Roberts",
    "Liam Johnson",
    "Sophia Martinez",
    "Olivia Davis",
    "Noah Thompson",
]

with open("attendees.txt", "w") as file:
    for attendee in attendees:
        file.write(attendee + "\n")
