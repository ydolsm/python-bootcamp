with open("attendees.txt", "a") as file:
    file.write("Alex Freze")
