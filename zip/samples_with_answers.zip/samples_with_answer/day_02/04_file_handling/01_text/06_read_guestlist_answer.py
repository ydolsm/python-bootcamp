with open("attendees.txt", "r") as file:
    attendees = file.read().splitlines()

print("Attendees:")

for index, attendee in enumerate(attendees, start=1):
    print(f"\t{index}.) {attendee}")