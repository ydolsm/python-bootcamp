# Load the files from the previous exercise in this format:
# 	Egg (Php 10): It's an egg.
# 	Milk (Php 50): Fresh cow milk.
# 	Bread (Php 35): A whole loaf.
# 	Apple (Php 30): Fresh apple.
# 	Rice (Php 60): A kilo of rice.
