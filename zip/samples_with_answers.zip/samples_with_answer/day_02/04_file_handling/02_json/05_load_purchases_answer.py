import json

with open('purchases.json', 'r') as file:
    purchases = json.load(file)

for purchase in purchases:
    name = purchase["Name"]
    price = purchase["Price"]
    description = purchase["Description"]

    print(f"{name} (Php {price}): {description}")